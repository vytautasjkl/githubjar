# PW-S1 Docker

To build and run application clone this repository and execute these docker commands in cloned project directory

**In macOS or Linux Terminal**:

```
docker run -it --rm -v "$PWD":/usr/src/mymaven -v "$HOME/.m2":/root/.m2 -w /usr/src/mymaven maven:3.8.3-jdk-11 mvn clean install

docker-compose up
```

**In Windows Command Prompt**:

```
docker run -it --rm -v "%CD%":/usr/src/mymaven -v "%HOME%\.m2":/root/.m2 -w /usr/src/mymaven maven:3.8.3-jdk-11 mvn clean install

docker-compose up
```

and open browser at address

http://localhost:8080/swagger-ui/

## TO-DO's

  * Implement add front end to docker compose