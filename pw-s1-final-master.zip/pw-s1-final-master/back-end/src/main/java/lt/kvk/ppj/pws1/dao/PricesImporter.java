package lt.kvk.ppj.pws1.dao;

import static lt.kvk.ppj.pws1.dao.Utils.openCsvToBean;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lt.kvk.ppj.pws1.jpa.entity.PriceEntity;
import lt.kvk.ppj.pws1.jpa.entity.ProductEntity;
import lt.kvk.ppj.pws1.jpa.repository.PriceRepository;
import lt.kvk.ppj.pws1.jpa.repository.ProductRepository;

@Service
@lombok.AllArgsConstructor
public class PricesImporter {

	@Autowired
	private final PriceRepository priceRepository;

	@Autowired
	private final ProductRepository productRepository;

	public void importCsv(final InputStream is) throws IOException {
		final List<PriceEntity> entitiesToSave = new ArrayList<>();
		for (final PriceCsvRow src : openCsvToBean(PriceCsvRow.class, is)) {

			// NOTE. Make SQL call for every product has low performance.
			// However, for amount and frequency import is used performance looks OK.
			final ProductEntity product = productRepository.findOneOrCreateByProductName(src.getProductName());

			final PriceEntity tgt = new PriceEntity();
			tgt.setProduct(product);
			tgt.setDateFrom(src.getDateFrom());
			tgt.setPaymentForAmount(src.getPaymentForAmount());
			tgt.setAmount(src.getAmount());
			entitiesToSave.add(tgt);
		}
		if (!entitiesToSave.isEmpty()) {

			// We use batch update to have better speed and
			// rollback transaction for whole file.
			priceRepository.saveAll(entitiesToSave);
		}
	}
}
