package lt.kvk.ppj.pws1.dao;

import java.math.BigDecimal;
import java.util.Date;

import com.opencsv.bean.CsvBindByPosition;
import com.opencsv.bean.CsvDate;

@lombok.Data
@lombok.NoArgsConstructor(force = true)
public class WorkResultCsvRow {

	@CsvBindByPosition(position = 0)
	private final String lastName;

	@CsvBindByPosition(position = 1)
	private final String firstName;

	@CsvBindByPosition(position = 2)
	private final String productName;

	@CsvBindByPosition(position = 3)
	private final BigDecimal producedAmount;

	@CsvBindByPosition(position = 4)
	@CsvDate("yyyy-MM-dd HH:mm")
	private final Date dateTime;

}
