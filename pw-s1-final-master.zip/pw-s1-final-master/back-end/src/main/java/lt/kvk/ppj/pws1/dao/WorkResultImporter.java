package lt.kvk.ppj.pws1.dao;

import static lt.kvk.ppj.pws1.dao.Utils.openCsvToBean;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import lt.kvk.ppj.pws1.jpa.entity.EmployeeEntity;
import lt.kvk.ppj.pws1.jpa.entity.ProductEntity;
import lt.kvk.ppj.pws1.jpa.entity.WorkResultEntity;
import lt.kvk.ppj.pws1.jpa.repository.EmployeeRepository;
import lt.kvk.ppj.pws1.jpa.repository.ProductRepository;
import lt.kvk.ppj.pws1.jpa.repository.WorkResultRepository;

@Service
@lombok.AllArgsConstructor
@Slf4j
public class WorkResultImporter {

	@Autowired
	private final WorkResultRepository workResultRepository;

	@Autowired
	private final EmployeeRepository employeeRepository;

	@Autowired
	private final ProductRepository productRepository;

	public void importCsv(final InputStream is) throws IOException {
		log.debug("Import started");
		final List<WorkResultEntity> entitiesToSave = new ArrayList<>();
		for (final WorkResultCsvRow src : openCsvToBean(WorkResultCsvRow.class, is)) {

			// NOTE. Make SQL call for every product and employee has low performance.
			// However, for amount and frequency import is used performance looks OK.
			final EmployeeEntity employee = employeeRepository.findOneOrCreateByFirstNameAndLastName(src.getFirstName(),
					src.getLastName());
			final ProductEntity product = productRepository.findOneOrCreateByProductName(src.getProductName());

			final WorkResultEntity tgt = new WorkResultEntity();
			tgt.setEmployee(employee);
			tgt.setProduct(product);
			tgt.setProducedAmount(src.getProducedAmount());
			tgt.setDateTime(src.getDateTime());

			entitiesToSave.add(tgt);
		}
		if (!entitiesToSave.isEmpty()) {

			// We use batch update to have better speed and
			// rollback transaction for whole file.
			workResultRepository.saveAll(entitiesToSave);
		}
	}
}
