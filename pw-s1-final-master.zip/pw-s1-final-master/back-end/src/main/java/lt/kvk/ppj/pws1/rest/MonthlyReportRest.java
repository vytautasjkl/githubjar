package lt.kvk.ppj.pws1.rest;

import static lt.kvk.ppj.pws1.rest.RestUtils.toResponseEntity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lt.kvk.ppj.pw.s1.calc.client.ApiClient;
import lt.kvk.ppj.pw.s1.calc.client.api.DefaultApi;
import lt.kvk.ppj.pw.s1.calc.client.model.CalcMonthlyReportRow;
import lt.kvk.ppj.pw.s1.server.api.MonthlyReportApi;
import lt.kvk.ppj.pw.s1.server.model.MonthlyReportLine;

/**
 * <b>NOTE</b>. To have proper documentation in Swagger UI you need
 * copy @ApiParam definitions from generated interfaces. It is workaround for
 * bug:<br/>
 * <a href=
 * "https://github.com/springfox/springfox/issues/1575">https://github.com/springfox/springfox/issues/1575</a>
 */
@RestController
@RequestMapping("/api")
@lombok.NoArgsConstructor(force = true)
public class MonthlyReportRest implements MonthlyReportApi {

	@Value("${pw.s1.calc.service.url}")
	private String calcSserviceUrl;

	private DefaultApi calcApi;

	@PostConstruct
	private void postConstruct() {
		final ApiClient client = new ApiClient();
		client.getAdapterBuilder().baseUrl(calcSserviceUrl);
		this.calcApi = client.createService(lt.kvk.ppj.pw.s1.calc.client.api.DefaultApi.class);
	}

	@Override
	public ResponseEntity<List<MonthlyReportLine>> getMonthlyReport() {
		try {
			List<CalcMonthlyReportRow> srcList = calcApi.getMonthlyReport().execute().body();
			List<MonthlyReportLine> repRecList = new ArrayList<>(srcList.size());
			for (final CalcMonthlyReportRow src : srcList) {
				final MonthlyReportLine dest = new MonthlyReportLine();
				dest.setProductName(src.getProductName());
				dest.setYear(src.getYear());
				dest.setMonth(src.getMonth());
				dest.setAmount(src.getAmount());
				dest.setPayment(src.getPayment());
				repRecList.add(dest);
			}
			return toResponseEntity(repRecList);
		} catch (IOException e) {
			throw new RestServiceException("Can't get monthly report", e);
		}
	}
}
