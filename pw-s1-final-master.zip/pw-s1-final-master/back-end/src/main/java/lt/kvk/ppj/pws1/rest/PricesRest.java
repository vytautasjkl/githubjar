package lt.kvk.ppj.pws1.rest;

import static lt.kvk.ppj.pws1.rest.RestUtils.toResponseEntity;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.annotations.ApiParam;
import lt.kvk.ppj.pw.s1.server.api.PricesApi;
import lt.kvk.ppj.pw.s1.server.model.Price;
import lt.kvk.ppj.pws1.dao.PricesImporter;
import lt.kvk.ppj.pws1.jpa.entity.PriceEntity;
import lt.kvk.ppj.pws1.jpa.entity.ProductEntity;
import lt.kvk.ppj.pws1.jpa.repository.PriceRepository;
import lt.kvk.ppj.pws1.jpa.repository.ProductRepository;

/**
 * <b>NOTE</b>. To have proper documentation in Swagger UI you need
 * copy @ApiParam definitions from generated interfaces. It is workaround for
 * bug:<br/>
 * <a href=
 * "https://github.com/springfox/springfox/issues/1575">https://github.com/springfox/springfox/issues/1575</a>
 */
@RestController
@RequestMapping("/api")
@lombok.AllArgsConstructor
public class PricesRest implements PricesApi {

	@Autowired
	private final PriceRepository priceRepository;

	@Autowired
	private final ProductRepository productRepository;

	@Autowired
	private final PricesImporter pricesImporter;

	@Override
	public ResponseEntity<Void> addPrice(@ApiParam(value = "") @Valid @RequestBody Price price) {
		return save(price, null);
	}

	@Override
	public ResponseEntity<Void> delPrice(@ApiParam(value = "Numeric ID of the price to delete.", //
			required = true) @PathVariable("id") Long priceId) {
		priceRepository.deleteById(priceId);
		return ResponseEntity.ok().build();
	}

	@Override
	public ResponseEntity<Price> getPrice(@ApiParam(value = "Numeric ID of the price to get.", //
			required = true) @PathVariable("id") Long priceId) {
		Optional<PriceEntity> optional = priceRepository.findById(priceId);
		if (optional.isPresent()) {
			return ResponseEntity.ok(toPrice(optional.get()));
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@Override
	public ResponseEntity<List<Price>> getPrices() {
		final List<Price> list = new ArrayList<>();
		for (final PriceEntity src : priceRepository.findAllByOrderByIdAsc()) {
			list.add(toPrice(src));
		}
		return toResponseEntity(list);
	}

	@Override
	public ResponseEntity<Void> updatePrice(@ApiParam(value = "") @Valid @RequestBody Price price) {
		return save(price, price.getId());
	}

	@Override
	public ResponseEntity<Void> uploadPricesCsv(
			@ApiParam(value = "file detail") @Valid @RequestPart("file") MultipartFile csvPricesFile) {
		try (final InputStream is = csvPricesFile.getInputStream()) {
			pricesImporter.importCsv(is);
			return ResponseEntity.ok().build();
		} catch (IOException e) {
			throw new RestServiceException("Can't import prices CSV file", e);
		}
	}

	private ResponseEntity<Void> save(final Price src, Long priceId) {
		final ProductEntity product = productRepository.findOneOrCreateByProductName(src.getProductName());
		final PriceEntity tgt = new PriceEntity(priceId);
		tgt.setProduct(product);
		tgt.setDateFrom(src.getDateFrom());
		tgt.setPaymentForAmount(src.getPaymentForAmount());
		tgt.setAmount(src.getAmount());
		priceRepository.save(tgt);
		return ResponseEntity.ok().build();
	}

	private static Price toPrice(PriceEntity src) {
		final Price tgt = new Price();
		tgt.setId(src.getId());
		tgt.setProductName(src.getProduct().getProductName());
		tgt.setAmount(src.getAmount());
		tgt.setPaymentForAmount(src.getPaymentForAmount());
		tgt.setDateFrom(src.getDateFrom());
		return tgt;
	}
}
