package lt.kvk.ppj.pws1.rest;

import static lt.kvk.ppj.pws1.rest.RestUtils.toResponseEntity;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.annotations.ApiParam;
import lt.kvk.ppj.pw.s1.server.api.WorkResultsApi;
import lt.kvk.ppj.pw.s1.server.model.WorkResult;
import lt.kvk.ppj.pws1.dao.WorkResultImporter;
import lt.kvk.ppj.pws1.jpa.entity.EmployeeEntity;
import lt.kvk.ppj.pws1.jpa.entity.ProductEntity;
import lt.kvk.ppj.pws1.jpa.entity.WorkResultEntity;
import lt.kvk.ppj.pws1.jpa.repository.EmployeeRepository;
import lt.kvk.ppj.pws1.jpa.repository.ProductRepository;
import lt.kvk.ppj.pws1.jpa.repository.WorkResultRepository;

/**
 * <b>NOTE</b>. To have proper documentation in Swagger UI you need
 * copy @ApiParam definitions from generated interfaces. It is workaround for
 * bug:<br/>
 * <a href=
 * "https://github.com/springfox/springfox/issues/1575">https://github.com/springfox/springfox/issues/1575</a>
 */
@RestController
@RequestMapping("/api")
@lombok.AllArgsConstructor
public class WorkResultsRest implements WorkResultsApi {

	@Autowired
	private final WorkResultRepository workResultRepository;

	@Autowired
	private final EmployeeRepository employeeRepository;

	@Autowired
	private final ProductRepository productRepository;

	@Autowired
	private final WorkResultImporter workResultImporter;

	@Override
	public ResponseEntity<Void> addWorkResult(@ApiParam(value = "") @Valid @RequestBody WorkResult workResult) {
		return save(workResult, null);
	}

	@Override
	public ResponseEntity<Void> delWorkResult(@ApiParam(value = "Numeric ID of the work result to delete.", //
			required = true) @PathVariable("id") Long workResultId) {
		workResultRepository.deleteById(workResultId);
		return ResponseEntity.ok().build();
	}

	@Override
	public ResponseEntity<WorkResult> getWorkResult(@ApiParam(value = "Numeric ID of the work result to get.", //
			required = true) @PathVariable("id") Long workResultId) {
		Optional<WorkResultEntity> optional = workResultRepository.findById(workResultId);
		if (optional.isPresent()) {
			return ResponseEntity.ok(toWorkResult(optional.get()));
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@Override
	public ResponseEntity<List<WorkResult>> getWorkResults() {
		final List<WorkResult> list = new ArrayList<>();
		for (final WorkResultEntity src : workResultRepository.findAllByOrderByIdAsc()) {
			list.add(toWorkResult(src));
		}
		return toResponseEntity(list);
	}

	@Override
	public ResponseEntity<Void> updateWorkResult(@ApiParam(value = "") @Valid @RequestBody WorkResult workResult) {
		return save(workResult, workResult.getId());
	}

	@Override
	public ResponseEntity<Void> uploadWorkResultsCsv(
			@ApiParam(value = "file detail") @Valid @RequestPart("file") MultipartFile csvWorkResultsFile) {
		try (final InputStream is = csvWorkResultsFile.getInputStream()) {
			workResultImporter.importCsv(is);
			return ResponseEntity.ok().build();
		} catch (IOException e) {
			throw new RestServiceException("Can't import work results CSV file", e);
		}
	}

	private static WorkResult toWorkResult(WorkResultEntity src) {
		final WorkResult tgt = new WorkResult();
		tgt.setId(src.getId());
		tgt.setLastName(src.getEmployee().getLastName());
		tgt.setFirstName(src.getEmployee().getFirstName());
		tgt.setProductName(src.getProduct().getProductName());
		tgt.setProducedAmount(src.getProducedAmount());
		tgt.setDateTime(src.getDateTime());
		return tgt;
	}

	private ResponseEntity<Void> save(final WorkResult src, Long workResultId) {
		final EmployeeEntity employee = employeeRepository.findOneOrCreateByFirstNameAndLastName(src.getFirstName(),
				src.getLastName());
		final ProductEntity product = productRepository.findOneOrCreateByProductName(src.getProductName());
		final WorkResultEntity tgt = new WorkResultEntity(workResultId);
		tgt.setEmployee(employee);
		tgt.setProduct(product);
		tgt.setProducedAmount(src.getProducedAmount());
		tgt.setDateTime(src.getDateTime());
		workResultRepository.save(tgt);
		return ResponseEntity.ok().build();
	}
}
