package lt.kvk.ppj.pws1.rest;

import static lt.kvk.ppj.pws1.rest.RestUtils.toResponseEntity;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.EqualsAndHashCode;
import lombok.ToString;
import lt.kvk.ppj.pw.s1.server.api.MonthlyReportApi;
import lt.kvk.ppj.pw.s1.server.model.CalcMonthlyReportRow;
import lt.kvk.ppj.pws1.jpa.entity.PriceEntity;
import lt.kvk.ppj.pws1.jpa.entity.WorkResultEntity;
import lt.kvk.ppj.pws1.jpa.repository.PriceRepository;
import lt.kvk.ppj.pws1.jpa.repository.WorkResultRepository;

/**
 * <b>NOTE</b>. To have proper documentation in Swagger UI you need
 * copy @ApiParam definitions from generated interfaces. It is workaround for
 * bug:<br/>
 * <a href=
 * "https://github.com/springfox/springfox/issues/1575">https://github.com/springfox/springfox/issues/1575</a>
 */
@RestController
@RequestMapping("/api")
@lombok.AllArgsConstructor
public class MonthlyReportRest implements MonthlyReportApi {

	@Autowired
	private final PriceRepository priceRepository;

	@Autowired
	private final WorkResultRepository workResultRepository;

	@Override
	public ResponseEntity<List<CalcMonthlyReportRow>> getMonthlyReport() {
		final Map<String, List<PriceEntity>> priceMap = getPriceMap();
		final Map<ReportKey, CalcMonthlyReportRow> reportMap = getReportMap(priceMap);
		List<CalcMonthlyReportRow> repRecList = getReportList(reportMap);
		return toResponseEntity(repRecList);
	}

	private static List<CalcMonthlyReportRow> getReportList(final Map<ReportKey, CalcMonthlyReportRow> reportMap) {
		final List<CalcMonthlyReportRow> repRecList = new ArrayList<>(reportMap.values());
		Collections.sort(repRecList, (v1, v2) -> {
			int c;
			c = v1.getAmount().compareTo(v2.getAmount());
			if (c != 0) {
				return -c;
			}
			c = v1.getPayment().compareTo(v2.getPayment());
			if (c != 0) {
				return +c;
			}
			c = v1.getMonth() - v2.getMonth();
			return +c;
		});
		for (final CalcMonthlyReportRow o : repRecList) {
			o.setAmount(noramlize(o.getAmount()));
			o.setPayment(noramlize(o.getPayment()));
		}
		return repRecList;
	}

	private static BigDecimal noramlize(BigDecimal v) {
		if (v.scale() <= 0) {
			return v;
		}
		if (v.scale() > 2) {
			v = v.setScale(2, RoundingMode.HALF_UP);
		}
		return v.stripTrailingZeros();
	}

	private Map<ReportKey, CalcMonthlyReportRow> getReportMap(final Map<String, List<PriceEntity>> priceMap) {
		final Calendar calendar = Calendar.getInstance();
		final Map<ReportKey, CalcMonthlyReportRow> reportMap = new HashMap<>();
		for (final WorkResultEntity workResult : workResultRepository.findAll()) {
			final String productName = workResult.getProduct().getProductName();
			final PriceEntity price = findPriseEntry(priceMap, productName, workResult.getDateTime());
			calendar.setTime(workResult.getDateTime());
			final BigDecimal payment = workResult.getProducedAmount().multiply(price.getPaymentForAmount())
					.divide(price.getAmount(), 5, RoundingMode.HALF_UP);
			final ReportKey key = new ReportKey(productName, calendar.get(Calendar.YEAR),
					(byte) (calendar.get(Calendar.MONTH) + 1));
			CalcMonthlyReportRow row = reportMap.get(key);
			if (row == null) {
				row = new CalcMonthlyReportRow();
				row.setProductName(key.productName);
				row.setYear(key.year);
				row.setMonth((int) key.month);
				row.setAmount(workResult.getProducedAmount());
				row.setPayment(payment);
				reportMap.put(key, row);
			} else {
				row.setAmount(row.getAmount().add(workResult.getProducedAmount()));
				row.setPayment(row.getPayment().add(payment));
			}
		}
		return reportMap;
	}

	private Map<String, List<PriceEntity>> getPriceMap() {
		final Map<String, List<PriceEntity>> priceMap = new TreeMap<>();
		for (final PriceEntity o : priceRepository.findAll()) {
			final List<PriceEntity> list = priceMap.computeIfAbsent(o.getProduct().getProductName(),
					key -> new ArrayList<>());
			list.add(o);
		}
		Comparator<PriceEntity> comparator = (o1, o2) -> o1.getDateFrom().compareTo(o2.getDateFrom());
		for (List<PriceEntity> list : priceMap.values()) {
			Collections.sort(list, comparator);
		}
		return priceMap;
	}

	private static PriceEntity findPriseEntry(Map<String, List<PriceEntity>> priceMap, String productName,
			Date dateTime) {
		List<PriceEntity> list = priceMap.get(productName);
		for (int i = list.size() - 1; i >= 0; i--) {
			PriceEntity o = list.get(i);
			if (o.getDateFrom().before(dateTime)) {
				return o;
			}
		}
		return null;
	}

	@ToString()
	@EqualsAndHashCode()
	private static class ReportKey {

		final String productName;

		final int year;

		final byte month;

		ReportKey(String productName, int year, byte month) {
			this.productName = productName;
			this.year = year;
			this.month = month;
		}
	}
}
