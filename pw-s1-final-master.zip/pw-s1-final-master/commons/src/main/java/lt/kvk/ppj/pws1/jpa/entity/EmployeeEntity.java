package lt.kvk.ppj.pws1.jpa.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@lombok.Data
@lombok.ToString(callSuper=true, exclude = {"workResults"})
@lombok.EqualsAndHashCode(callSuper=true, exclude = {"workResults"})
@Entity(name = "Employee")
@Table(name = "darbininkas", uniqueConstraints = //
@UniqueConstraint(columnNames = { "pavarde", "vardas" }))
@lombok.NoArgsConstructor
public class EmployeeEntity extends AbstractBaseEntity {

	private static final long serialVersionUID = 1L;

	@Column(name = "vardas", nullable = false)
	private String firstName;

	@Column(name = "pavarde", nullable = false)
	private String lastName;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "employee")
	private Set<WorkResultEntity> workResults;

}
