package lt.kvk.ppj.pws1.jpa.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

@lombok.Data
@lombok.ToString(callSuper=true)
@lombok.EqualsAndHashCode(callSuper=true)
@Entity(name = "Price")
@Table(name = "gamybos_norma", uniqueConstraints = //
@UniqueConstraint(columnNames = { "data_nuo", "gaminys_id" }))
@lombok.NoArgsConstructor
public class PriceEntity extends AbstractBaseEntity {

	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "gaminys_id", nullable = false)
	private ProductEntity product;

	@Column(name = "kiekis", nullable = false, precision = 12, scale = 4)
	private BigDecimal amount;

	@Column(name = "uzmokestis_us_kieki", nullable = false, precision = 12, scale = 4)
	private BigDecimal paymentForAmount;

	@Temporal(TemporalType.DATE)
	@Column(name = "data_nuo", nullable = false)
	private Date dateFrom;

	public PriceEntity(Long id) {
		super(id);
	}

}
