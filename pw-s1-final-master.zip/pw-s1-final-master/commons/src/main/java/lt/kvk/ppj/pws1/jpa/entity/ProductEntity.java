package lt.kvk.ppj.pws1.jpa.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@lombok.Data
@lombok.ToString(callSuper=true, exclude = {"prices", "workResults"})
@lombok.EqualsAndHashCode(callSuper=true, exclude = {"prices", "workResults"})
@Entity(name = "Product")
@Table(name = "gaminys", uniqueConstraints = //
@UniqueConstraint(columnNames = "pavadinimas"))
@lombok.NoArgsConstructor
public class ProductEntity  extends AbstractBaseEntity {

	private static final long serialVersionUID = 1L;

	@Column(name = "pavadinimas", unique = true, nullable = false)
	private String productName;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "product")
	private Set<PriceEntity> prices;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "product")
	private Set<WorkResultEntity> workResults;

}
