package lt.kvk.ppj.pws1.jpa.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

@lombok.Data
@lombok.ToString(callSuper=true)
@lombok.EqualsAndHashCode(callSuper=true)
@Entity(name = "WorkResult")
@Table(name = "darbo_rezultatas", uniqueConstraints = //
@UniqueConstraint(columnNames = { "data_laikas", "darbininkas_id", "gaminys_id" }))
@lombok.NoArgsConstructor
public class WorkResultEntity extends AbstractBaseEntity {

	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "gaminys_id", nullable = false)
	private ProductEntity product;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "darbininkas_id", nullable = false)
	private EmployeeEntity employee;

	@Column(name = "kiekis", nullable = false, precision = 12, scale = 4)
	private BigDecimal producedAmount;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "data_laikas", nullable = false, length = 29)
	private Date dateTime;

	public WorkResultEntity(Long id) {
		super(id);
	}
}
