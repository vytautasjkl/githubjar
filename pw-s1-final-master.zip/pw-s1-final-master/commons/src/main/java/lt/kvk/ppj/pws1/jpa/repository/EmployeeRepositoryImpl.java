package lt.kvk.ppj.pws1.jpa.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import lt.kvk.ppj.pws1.jpa.entity.EmployeeEntity;

//REF:
//https://dzone.com/articles/add-custom-functionality-to-a-spring-data-reposito
//https://www.baeldung.com/circular-dependencies-in-spring
@Repository
public class EmployeeRepositoryImpl implements EmployeeRepositoryCustom {

	private final EmployeeRepository employeeRepository;

	@Autowired
	public EmployeeRepositoryImpl(@Lazy EmployeeRepository employeeRepository) {
		this.employeeRepository = employeeRepository;
	}

	@Override
	public EmployeeEntity findOneOrCreateByFirstNameAndLastName(String firstName, String lastName) {
		EmployeeEntity employee = employeeRepository.findOneByFirstNameAndLastName(firstName,
				lastName);
		if (employee == null) {
			employee = new EmployeeEntity();
			employee.setFirstName(firstName);
			employee.setLastName(lastName);
			employee = employeeRepository.save(employee);
		}
		return employee;
	}
}
