package lt.kvk.ppj.pws1.jpa.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import lt.kvk.ppj.pws1.jpa.entity.PriceEntity;

@RepositoryRestResource(path = "prices", exported = false)
public interface PriceRepository extends PagingAndSortingRepository<PriceEntity, Long> {

	Iterable<PriceEntity> findAllByOrderByIdAsc();
}
