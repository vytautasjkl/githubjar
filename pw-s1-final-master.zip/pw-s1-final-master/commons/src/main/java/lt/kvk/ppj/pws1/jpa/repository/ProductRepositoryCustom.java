package lt.kvk.ppj.pws1.jpa.repository;

import org.springframework.data.repository.query.Param;

import lt.kvk.ppj.pws1.jpa.entity.ProductEntity;

public interface ProductRepositoryCustom {

	ProductEntity findOneOrCreateByProductName(@Param("productName") String productName);
}
