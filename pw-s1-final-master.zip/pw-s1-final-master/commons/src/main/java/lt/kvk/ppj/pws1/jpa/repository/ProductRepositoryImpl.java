package lt.kvk.ppj.pws1.jpa.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import lt.kvk.ppj.pws1.jpa.entity.ProductEntity;

// REF:
// https://dzone.com/articles/add-custom-functionality-to-a-spring-data-reposito
// https://www.baeldung.com/circular-dependencies-in-spring
@Repository
public class ProductRepositoryImpl implements ProductRepositoryCustom {

	private final ProductRepository productRepository;

	@Autowired
	public ProductRepositoryImpl(@Lazy ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	@Override
	public ProductEntity findOneOrCreateByProductName(String productName) {
		ProductEntity product = productRepository.findOneByProductName(productName);
		if (product == null) {
			product = new ProductEntity();
			product.setProductName(productName);
			product = productRepository.save(product);
		}
		return product;
	}
}
