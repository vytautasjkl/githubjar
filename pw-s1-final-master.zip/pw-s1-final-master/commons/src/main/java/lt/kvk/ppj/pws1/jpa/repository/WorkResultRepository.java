package lt.kvk.ppj.pws1.jpa.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import lt.kvk.ppj.pws1.jpa.entity.WorkResultEntity;

@RepositoryRestResource(path = "work-results", exported = false)
public interface WorkResultRepository extends PagingAndSortingRepository<WorkResultEntity, Long> {

	Iterable<WorkResultEntity> findAllByOrderByIdAsc();
}
