package lt.kvk.ppj.pws1.rest;

@SuppressWarnings("serial")
public class RestServiceException extends RuntimeException {

	public RestServiceException(String message) {
		super(message);
	}

	public RestServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public RestServiceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
