export enum ROUTE {

  PRICE_ADD = 'price-add',
  PRICES = 'prices',

  WORK_RESULT_ADD = 'work-result-add',
  WORK_RESULTS = 'work-results',

  MONTHLY_REPORT = 'monthly-report'
}
