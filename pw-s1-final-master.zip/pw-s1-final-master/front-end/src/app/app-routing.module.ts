import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ROUTE } from './app-routing.model';

import { MonthlyReportComponent } from './component/monthly-report/monthly-report.component';
import { PriceDetailsComponent } from './component/price-details/price-details.component';
import { PricesComponent } from './component/prices/prices.component';
import { WorkResultDetailsComponent } from './component/work-result-details/work-result-details.component';
import { WorkResultsComponent } from './component/work-results/work-results.component';

const routes: Routes = [
  { path: ROUTE.PRICE_ADD, component: PriceDetailsComponent },
  { path: ROUTE.PRICES, component: PricesComponent },
  { path: ROUTE.PRICES + '/:id', component: PriceDetailsComponent },
  { path: ROUTE.WORK_RESULT_ADD, component: WorkResultDetailsComponent },
  { path: ROUTE.WORK_RESULTS, component: WorkResultsComponent },
  { path: ROUTE.WORK_RESULTS + '/:id', component: WorkResultDetailsComponent },
  { path : ROUTE.MONTHLY_REPORT, component : MonthlyReportComponent },
  { path : '', component : MonthlyReportComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
