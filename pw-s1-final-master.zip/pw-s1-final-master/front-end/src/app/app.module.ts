import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PricesComponent } from './component/prices/prices.component';
import { PriceDetailsComponent } from './component/price-details/price-details.component';
import { WorkResultsComponent } from './component/work-results/work-results.component';
import { WorkResultDetailsComponent } from './component/work-result-details/work-result-details.component';
import { MonthlyReportComponent } from './component/monthly-report/monthly-report.component';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ApiModule } from './api/api.module';
import { NavigationComponent } from './component/navigation/navigation.component';

@NgModule({
  declarations: [
    AppComponent,
    PricesComponent,
    PriceDetailsComponent,
    WorkResultsComponent,
    WorkResultDetailsComponent,
    MonthlyReportComponent,
    NavigationComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    NgbModule,
    ApiModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
