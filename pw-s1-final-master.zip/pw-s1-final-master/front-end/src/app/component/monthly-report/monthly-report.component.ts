import { Component, OnInit } from '@angular/core';

import { ApiService } from '../../api/services';
import { MonthlyReportLine } from 'src/app/api/models';
import { ROUTE } from 'src/app/app-routing.model';

@Component({
  selector: 'app-monthly-report',
  templateUrl: './monthly-report.component.html',
  styleUrls: ['./monthly-report.component.css']
})
export class MonthlyReportComponent implements OnInit {

  readonly ROUTE_MONTHLY_REPORT = ROUTE.MONTHLY_REPORT;

  rows: MonthlyReportLine[];

  constructor(private api: ApiService) { }

  ngOnInit() {
    this.api.getMonthlyReport().subscribe(
      data => this.rows = data);
  }
}
