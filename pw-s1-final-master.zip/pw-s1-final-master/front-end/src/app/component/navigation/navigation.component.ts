import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

import { NgbTabChangeEvent } from '@ng-bootstrap/ng-bootstrap';

import { ROUTE } from 'src/app/app-routing.model';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {

  readonly ROUTE = ROUTE;

  @Input() activeId: string;

  constructor(private router: Router) { }

  ngOnInit() {
  }

  tabChange(event: NgbTabChangeEvent) {
    this.router.navigate([event.nextId]);
  }
}
