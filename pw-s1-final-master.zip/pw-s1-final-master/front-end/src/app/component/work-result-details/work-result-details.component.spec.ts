import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkResultDetailsComponent } from './work-result-details.component';

describe('WorkResultDetailsComponent', () => {
  let component: WorkResultDetailsComponent;
  let fixture: ComponentFixture<WorkResultDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkResultDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkResultDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
