import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { first } from 'rxjs/operators';

import { ROUTE } from 'src/app/app-routing.model';

import { ApiService } from '../../api/services';
import { WorkResult } from '../../api/models/work-result';

@Component({
  selector: 'app-work-results',
  templateUrl: './work-results.component.html',
  styleUrls: ['./work-results.component.css']
})
export class WorkResultsComponent implements OnInit {

  readonly ROUTE_WORK_RESULTS = ROUTE.WORK_RESULTS;

  rows: WorkResult[];

  constructor(private api: ApiService, private router: Router) { }

  ngOnInit() {
    this.updateRows();
  }

  private updateRows(): void {
    this.api.getWorkResults().subscribe(
      data => this.rows = data);
  }

  deleteRow(row: WorkResult): void {
    if (!confirm('Are you sure to delete work result entry')) {
      return;
    }
    this.api.delWorkResult(row.id)
      .subscribe( data => {
        this.rows = this.rows.filter(o => o !== row);
      });
  }

  editRow(row: WorkResult): void {
    this.router.navigate([ROUTE.WORK_RESULTS, row.id]);
  }

  addRow(): void {
    this.router.navigate([ROUTE.WORK_RESULT_ADD]);
  }

  // REF.:
  // https://stackoverflow.com/questions/47936183/angular-file-upload
  handleFileInput(files: FileList) {
    const fileToUpload: File = files.item(0);
    this.api.uploadWorkResultsCsv(fileToUpload)
    .pipe(first()).subscribe(
      data => {
        console.log('Uploaded');
        this.updateRows();
      },
      error => {
        console.log(error);
        alert(error);
      });
  }
}
